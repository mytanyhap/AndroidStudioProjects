package edu.uncc.assignment10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BillAdapter extends ArrayAdapter<Bill> {

    public BillAdapter(@NonNull Context context, int resource, @NonNull List<Bill> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if(convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.custom, parent, false);
        }

        Bill bill = getItem(position);

        TextView name  = convertView.findViewById(R.id.bill_name);
        TextView amount = convertView.findViewById(R.id.bill_amount);
        TextView discount = convertView.findViewById(R.id.bill_discount);
        TextView total = convertView.findViewById(R.id.total_bill);
        TextView category = convertView.findViewById(R.id.bill_category);
        TextView date = convertView.findViewById(R.id.bill_date);

        assert bill != null;
        name.setText(bill.getName());
        amount.setText(String.valueOf(bill.getAmount()));
        discount.setText(String.valueOf(bill.getDiscount()));

        double dAmount = Double.parseDouble(amount.getText().toString());
        double dDiscount = Double.parseDouble(discount.getText().toString());
        double calc = (dAmount * (dDiscount / 100));
        double finalBill = dAmount - calc;
        total.setText(String.format("%.2f", finalBill));

        category.setText(bill.getCategory());

        Date billDate = bill.getBillDate();
        SimpleDateFormat dateFormat = new SimpleDateFormat("M/d/yyyy");
        String formatDate = dateFormat.format(billDate);
        date.setText(formatDate);

        return convertView;
    }
}
