package edu.uncc.assignment10;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import edu.uncc.assignment10.databinding.FragmentBillsBinding;

public class BillsFragment extends Fragment {
    public BillsFragment() {
        // Required empty public constructor
    }

    String sortAttribute = "Date", sortOrder = "ASC";

    public void setSortItems(String sortAttribute, String sortOrder) {
        this.sortAttribute = sortAttribute;
        this.sortOrder = sortOrder;
        sortBills();
        binding.textViewSortedBy.setText("Sorted By " + sortAttribute + " (" + sortOrder + ")");
    }

    FragmentBillsBinding binding;

    private ArrayList<Bill> mBills = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentBillsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ListView listView = binding.listView;
        BillAdapter adapter = new BillAdapter(getActivity(), R.layout.custom, mBills);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bill bill = adapter.getItem(i);
                mListener.goToBillSummary(bill);
            }
        });

        mBills.clear();
        mBills.addAll(mListener.getAllBills());
        sortBills();
        adapter.notifyDataSetChanged();

        binding.textViewSortedBy.setText("Sorted By " + sortAttribute + " (" + sortOrder + ")");

        binding.buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBills.clear();
                adapter.notifyDataSetChanged();
                mListener.clearAllBills();
            }
        });

        binding.buttonNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoCreateBill();
            }
        });

        binding.buttonSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mListener.gotoSortSelection();
                adapter.notifyDataSetChanged();
            }
        });
    }

    private void sortBills() {
        if(sortAttribute.equals("Date")) {
            Collections.sort(mBills, new Comparator<Bill>() {
                @Override
                public int compare(Bill b1, Bill b2) {
                    return sortOrder.equals("ASC") ? b1.getBillDate().compareTo(b2.getBillDate()) : b2.getBillDate().compareTo(b1.getBillDate());
                }
            });
        }else if(sortAttribute.equals("Category")) {
            Collections.sort(mBills, new Comparator<Bill>() {
                @Override
                public int compare(Bill b1, Bill b2) {
                    return sortOrder.equals("ASC") ? b1.getCategory().compareTo(b2.getCategory()) : b2.getCategory().compareTo(b1.getCategory());
                }
            });
        } else if(sortAttribute.equals("Discount")) {
            Collections.sort(mBills, new Comparator<Bill>() {
                @Override
                public int compare(Bill b1, Bill b2) {
                    return sortOrder.equals("ASC") ? Double.compare(b1.getDiscount(), b2.getDiscount()) : Double.compare(b2.getDiscount(), b1.getDiscount());
                }
            });
        }
    }

    BillsListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof BillsListener) {
            mListener = (BillsListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement BillsListener");
        }
    }

    interface BillsListener {
        void goToBillSummary(Bill bill);
        ArrayList<Bill> getAllBills();
        void gotoCreateBill();
        void gotoSortSelection();
        void clearAllBills();
    }

}