package com.example.assignment4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    EditText editTextName, editTextEmail;
    RadioGroup radioGroup;

    public static final String ROLE = "ROLE";
    public static final String KEY_PROFILE = "PROFILE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextName = findViewById(R.id.editTextName);
        radioGroup = findViewById(R.id.radioGroup);

        findViewById(R.id.buttonNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = editTextName.getText().toString();
                String email = editTextEmail.getText().toString();

                int selectId = radioGroup.getCheckedRadioButtonId();
                String role = "";
                if (selectId == R.id.radioButtonStudent) {
                    role = getString(R.string.Student);
                } else if (selectId == R.id.radioButtonEmployee) {
                    role = getString(R.string.Email);
                } else if (selectId == R.id.radioButtonOther) {
                    role = getString(R.string.Other);
                }

                if (name.isEmpty()) {
                    Toast.makeText(SecondActivity.this, "Enter Name", Toast.LENGTH_SHORT).show();
                } else if (email.isEmpty()) {
                    Toast.makeText(SecondActivity.this, "Enter Email", Toast.LENGTH_SHORT).show();
                } else if (selectId==-1) {
                    Toast.makeText(SecondActivity.this, "Please select a role", Toast.LENGTH_SHORT).show();




            } else {
                    Profile profile = new Profile(name, email, role);

                    Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);

                  intent.putExtra(KEY_PROFILE,profile);
                 startActivity(intent);
                }
            }
        });
    }
}
