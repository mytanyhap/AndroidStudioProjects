package com.example.assignment4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FourthActivity extends AppCompatActivity {
EditText editTextTextName, editTextTextEmail;
RadioGroup radioGroup2;
    public static final String ROLE = "role";
    public static final String KEY_PROFILES = "profile";
Profile profile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_fourth);
        editTextTextEmail = findViewById(R.id.editTextTextEmail);
        editTextTextName = findViewById(R.id.editTextTextName);
        radioGroup2 = findViewById(R.id.radioGroup2);

        findViewById(R.id.buttonSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextTextName.getText().toString();
                String email = editTextTextEmail.getText().toString();


                int selectId = radioGroup2.getCheckedRadioButtonId();
                String role = "";

                if (selectId == R.id.radioButtonNewStudent) {
                    role = getString(R.string.Student);
                } else if (selectId == R.id.radioButtonNewEmployee) {
                    role = getString(R.string.Employees);
                } else if (selectId == R.id.radioButtonNewOther) {
                    role = getString(R.string.Other);
                }
                if (name.isEmpty()) {
                    Toast.makeText(FourthActivity.this, "Enter Name", Toast.LENGTH_SHORT).show();
                } else if (email.isEmpty()) {
                    Toast.makeText(FourthActivity.this, "Enter Email", Toast.LENGTH_SHORT).show();
                } else if (selectId==-1) {
                    Toast.makeText(FourthActivity.this, "Please select a role", Toast.LENGTH_SHORT).show();





                } else {
                    Profile profile = new Profile(name, email, role);
                    Intent intent = new Intent();
                    intent.putExtra(KEY_PROFILES, profile);

                    setResult(RESULT_OK, intent);
                    finish(); // This will return to ThirdActivity
                }
            }
        });



findViewById(R.id.buttonCancel).setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
finish();
    }
});
    }
}