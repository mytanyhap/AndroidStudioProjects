package com.example.assignment4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class ThirdActivity extends AppCompatActivity {
    TextView textViewName, textViewEmployee, textViewEmail;
    Profile profile;

    private ActivityResultLauncher<Intent> startFourthActivityLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        textViewName = findViewById(R.id.textViewNewName);
        textViewEmail = findViewById(R.id.textViewNewEmail);
        textViewEmployee = findViewById(R.id.textViewNewEmployee);

        // Initialize the ActivityResultLauncher
        startFourthActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            Intent data = result.getData();
                            if (data != null) {
                                profile = (Profile) data.getSerializableExtra(FourthActivity.KEY_PROFILES);

                                updateTextViews(); // Update TextViews with the new profile data
                            }
                        }
                    }
                });


        if (getIntent() != null && getIntent().hasExtra(SecondActivity.KEY_PROFILE)) {
            profile = (Profile) getIntent().getSerializableExtra(SecondActivity.KEY_PROFILE);
            updateTextViews();
        }

        findViewById(R.id.buttonUpdate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ThirdActivity.this, FourthActivity.class);
                intent.putExtra(SecondActivity.KEY_PROFILE, profile); 
                startFourthActivityLauncher.launch(intent);
            }
        });
    }

    private void updateTextViews() {
        if (profile != null) {
            textViewName.setText(profile.getName());
            textViewEmail.setText(profile.getEmail());
            textViewEmployee.setText(profile.getRole());
        } else {
            textViewName.setText("N/A");
            textViewEmail.setText("N/A");
            textViewEmployee.setText("N/A");
        }
    }
}
