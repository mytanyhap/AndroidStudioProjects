package com.example.assignment05;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.DatePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class SelectDoBActivity extends AppCompatActivity {
DatePicker datePicker;
    public static final String DATE_KEY="date";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_select_do_bactivity);

datePicker = findViewById(R.id.datePicker);
Calendar calendar = Calendar.getInstance();
calendar.add(Calendar.YEAR,-18);
datePicker.setMaxDate(calendar.getTimeInMillis());

findViewById(R.id.buttonCalendarSubmit).setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
int day = datePicker.getDayOfMonth();
int month = datePicker.getMonth();
int year = datePicker.getYear();

String selectedDate = (month +1) + "/" + day + "/" + year;
Intent intent = new Intent();
intent.putExtra(DATE_KEY,selectedDate);
setResult(RESULT_OK, intent);
finish();



    }
});

findViewById(R.id.buttonCalendarCancel).setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        finish();
    }
});
    }


}