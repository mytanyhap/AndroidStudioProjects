package com.example.assignment05;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class CreateUserActivity extends AppCompatActivity {
EditText editTextEnterName, editTextEnterEmail, editTextEnterAge;
TextView textViewCountrySelection, textViewDobSelection;
private Data data;
public static final String USER_KEY = "user";
private String selectedDate;
    public static final String DATE_KEY="date";

    User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_user);
        editTextEnterAge = findViewById(R.id.editTextEnterAge);
        editTextEnterEmail = findViewById(R.id.editTextEnterEmail);
        editTextEnterName = findViewById(R.id.editTextEnterName);

textViewCountrySelection = findViewById(R.id.textViewCountrySelection);
textViewDobSelection = findViewById(R.id.textViewDobSelection);
data = new Data();

findViewById(R.id.buttonCountrySelect).setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        final int [] selectedIndex = {0};

        AlertDialog.Builder builder = new AlertDialog.Builder(CreateUserActivity.this);
        builder.setTitle("Select a Country")
                        .setSingleChoiceItems(Data.getCountries(), selectedIndex[0], new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                selectedIndex[0]=which;
                            }
                        })
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int id) {
                                        String selectedCountry = Data.getCountries()[selectedIndex[0]];
                                        textViewCountrySelection.setText( selectedCountry);
                                        dialog.dismiss();
                                    }
                                })
                                        .setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.dismiss();
                                            }
                                        });



        builder.create().show();
    }
});

       ActivityResultLauncher<Intent> startGetDob = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode() == RESULT_OK){
                            selectedDate = result.getData().getStringExtra(DATE_KEY);
                            textViewDobSelection.setText( selectedDate);
                        }else{

                        }
                    }
                }
        );



findViewById(R.id.buttonDobSelect).setOnClickListener(new View.OnClickListener() {

    @Override
    public void onClick(View v) {
//Need a Launcher
        Intent intent = new Intent(CreateUserActivity.this,SelectDoBActivity.class );
        startGetDob.launch(intent);

    }
});


findViewById(R.id.buttonSubmit).setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {


    String name = editTextEnterName.getText().toString();
    String email = editTextEnterEmail.getText().toString();
    String age= editTextEnterAge.getText().toString();

    String country = textViewCountrySelection.getText().toString();
    String Dob = textViewDobSelection.getText().toString().replace("Dob:","");

        // Name Validation
        if (name.isEmpty()) {
            Toast.makeText(CreateUserActivity.this, "Name cannot be empty.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Email validation
        if (email.isEmpty()) {
            Toast.makeText(CreateUserActivity.this, "Email cannot be empty.", Toast.LENGTH_SHORT).show();
            return;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(CreateUserActivity.this, "Please enter a valid email address.", Toast.LENGTH_SHORT).show();
            return;
        }

        //Age validation
        if (age.isEmpty()) {
            Toast.makeText(CreateUserActivity.this, "Age cannot be empty.", Toast.LENGTH_SHORT).show();
            return;
        }
        int ageTx;
        try {
            ageTx = Integer.parseInt(age);
            if (ageTx <= 0) {
                Toast.makeText(CreateUserActivity.this, "Please enter a valid ageTx.", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(CreateUserActivity.this, "Age must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Country Validation
        if (country.isEmpty() || country.equals("N/A")) {
            Toast.makeText(CreateUserActivity.this, "Please select a country.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate Date of Birth
  ;      if (Dob.isEmpty() || Dob.equals("N/A")) {
            Toast.makeText(CreateUserActivity.this, "Please select your date of birth.", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = new User(name,email,country, Dob, ageTx);


    Toast.makeText(CreateUserActivity.this, "User Created Successfully!", Toast.LENGTH_SHORT).show();


    Intent intent = new Intent(CreateUserActivity.this,ProfileActivity.class);
    intent.putExtra(USER_KEY,user);
    startActivity(intent);

    }
});



    }
}