package com.example.assignment6;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements MainFragment.MainFragmentListner, CreateUserFragment.CreateUserFragmentListener, ProfileFragment.ProfileFragmentListener, EditUserFragment.EditUserFragmentListener {

    // Standard method called when an Android activity is created.
    // It initializes the activity and sets up the initial layout.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, new MainFragment()) //where are we going to add it and whats the fragment we are going to add
                .commit();
    }

    // method loads the ProfileFragment,
    // passing a Profile object and adding the transaction to the back stack.
    @Override
    public void gotoProfile(Profile profile) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, ProfileFragment.newInstance(profile), "Profile-Fragment")
                .addToBackStack(null)
                .commit();
    }
    //This method replaces the current fragment with the CreateUserFragment.
    @Override
    public void gotoCreateUserFragment() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new CreateUserFragment())
                .addToBackStack(null)
                .commit();
    }
    //This method loads the EditUserFragment, passing a Profile object to it.
    @Override
    public void gotoeditUser(Profile profile) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, EditUserFragment.newInstance(profile))
                .addToBackStack(null)
                .commit();
    }
    // This method ensures that the ProfileFragment is updated
    // with new profile information after a change is made.
    @Override
    public void onUserUpdated(Profile profile) {
        ProfileFragment profileFragment = (ProfileFragment) getSupportFragmentManager().findFragmentByTag("Profile-Fragment");
        if (profileFragment != null) {
            profileFragment.updateProfile(profile);
        }
    }
    //Method returns to the previous fragment when an operation is canceled
    @Override
    public void onCancel() {
        getSupportFragmentManager().popBackStack();
    }
}

