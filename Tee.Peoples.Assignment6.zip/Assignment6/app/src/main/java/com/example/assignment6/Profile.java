package com.example.assignment6;

import java.io.Serializable;

public class Profile implements Serializable {
    String name, email,selectedRole;

    public Profile(String name, String email, String selectedRole) {
        this.name = name;
        this.email = email;
        this.selectedRole = selectedRole;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSelectedRole() {
        return selectedRole;
    }

    public void setSelectedRole(String selectedRole) {
        this.selectedRole = selectedRole;
    }
}
