package com.example.assignment6;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.assignment6.databinding.FragmentProfileBinding;


public class ProfileFragment extends Fragment {
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM_PROFILE = "ARG_PARAM_PROFILE ";
    private Profile mProfile;
    public ProfileFragment() {
        // Required empty public constructor
    }

    public static ProfileFragment newInstance(Profile profile) {
        //going to send a profile object for the parameter
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM_PROFILE, profile);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            //instead og getString you have to getSerializable
            mProfile = (Profile) getArguments().getSerializable(ARG_PARAM_PROFILE);

        }
    }

FragmentProfileBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.textViewName.setText(mProfile.getName());
        binding.textViewProfileEmail.setText(mProfile.getEmail());
        binding.textViewProfileRolet.setText(mProfile.getSelectedRole());


        binding.buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoeditUser(new Profile(mProfile.getName(), mProfile.getEmail(), mProfile.getSelectedRole()));
            }
        });
    }

    ProfileFragmentListener mListener;


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (ProfileFragmentListener) context;
    }

    // ProfileFragment.java
    public void updateUser(Profile profile) {
        mProfile = profile;
        binding.textViewName.setText(mProfile.getName());
        binding.textViewProfileEmail.setText(mProfile.getEmail());
        binding.textViewProfileRolet.setText(mProfile.getSelectedRole());
    }

    public void updateProfile(Profile profile) {
        mProfile = profile;
        if (mProfile != null) {
            binding.textViewName.setText(mProfile.getName());
            binding.textViewProfileEmail.setText(mProfile.getEmail());
            binding.textViewProfileRolet.setText(mProfile.getSelectedRole());
        }
    }


    interface ProfileFragmentListener{
        void gotoeditUser(Profile profile);
    }
}
