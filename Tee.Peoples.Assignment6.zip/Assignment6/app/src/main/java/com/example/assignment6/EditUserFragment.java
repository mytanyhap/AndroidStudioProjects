package com.example.assignment6;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.example.assignment6.databinding.FragmentEditUserBinding;

public class EditUserFragment extends Fragment {

    private static final String ARG_PARAM_PROFILE = "ARG_PARAM_PROFILE";
    private Profile mProfile;
    private FragmentEditUserBinding binding;
    private EditUserFragmentListener mListener;

    public EditUserFragment() {
        // Required empty public constructor
    }

    public static EditUserFragment newInstance(Profile profile) {
        EditUserFragment fragment = new EditUserFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM_PROFILE, profile);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mProfile = (Profile) getArguments().getSerializable(ARG_PARAM_PROFILE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentEditUserBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
       binding.editTextEditName.setText(mProfile.getName());
        binding.editTextEditEmail.setText(mProfile.getEmail());
        setSelectedRole();

        binding.buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (binding.editTextEditName.getText().toString().isEmpty()) {
                    Toast.makeText(getActivity(), "Enter Valid Name", Toast.LENGTH_SHORT).show();
                } else if (binding.editTextEditEmail.getText().toString().isEmpty()) {
                    Toast.makeText(getActivity(), "Enter Valid Email", Toast.LENGTH_SHORT).show();

                } else {


                    handleSubmit();
                }
            }
        });

        binding.buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onCancel();
            }
        });
    }

    private void setSelectedRole() {
        if (mProfile != null) {
            String selectedRole = mProfile.getSelectedRole();
            switch (selectedRole) {
                case "Student":
                    binding.radioButtonEditStudent.setChecked(true);
                    break;
                case "Employee":
                    binding.radioButtonEditEmployee.setChecked(true);
                    break;
                case "Other":
                    binding.radioButtonEditOther.setChecked(true);
                    break;

            }
            if (selectedRole.isEmpty()){
                Toast.makeText(getActivity(), "Select a Role", Toast.LENGTH_SHORT).show();
            }

        }
    }



    private String getSelectedRole() {
        if (binding.radioButtonEditStudent.isChecked()) {
            return "Student";
        } else if (binding.radioButtonEditEmployee.isChecked()) {
            return "Employee";
        } else if (binding.radioButtonEditOther.isChecked()) {
            return "Other";
        }
        return "";
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

            mListener = (EditUserFragmentListener) context;
    }

    private void handleSubmit() {
        String name = binding.editTextEditName.getText().toString();
        String email = binding.editTextEditEmail.getText().toString();
        String selectedRole = getSelectedRole();

        // Validate the inputs
        if (name.isEmpty()) {
            Toast.makeText(getActivity(), "Please enter your name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(getActivity(), "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedRole == null || selectedRole.isEmpty()) {
            Toast.makeText(getActivity(), "Please select a role", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new Profile object with updated data
        Profile updatedProfile = new Profile(name, email, selectedRole);

        // Notify the listener that the profile has been updated
        mListener.onUserUpdated(updatedProfile);

        // Optionally show a success message
        Toast.makeText(getActivity(), "Profile updated successfully!", Toast.LENGTH_SHORT).show();

        // Pop the back stack to return to the ProfileFragment
        requireActivity().getSupportFragmentManager().popBackStack();
    }


    interface EditUserFragmentListener {
        void onUserUpdated(Profile profile);
        void onCancel();
    }
}
