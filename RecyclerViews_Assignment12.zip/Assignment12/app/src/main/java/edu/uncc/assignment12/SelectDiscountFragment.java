package edu.uncc.assignment12;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;

import edu.uncc.assignment12.databinding.FragmentSelectDiscountBinding;


public class SelectDiscountFragment extends Fragment {
    public SelectDiscountFragment() {
        // Required empty public constructor
    }

    RecyclerView recyclerView;
    FragmentSelectDiscountBinding binding;
    LinearLayoutManager layoutManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSelectDiscountBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.seekBar.setMax(50);
        binding.seekBar.setProgress(25);

        binding.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                binding.textViewSeekBarProgress.setText(progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        recyclerView = binding.recyclerView;
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        ArrayList<String> discounts = new ArrayList<>();
        discounts.add("10%");
        discounts.add("15%");
        discounts.add("18%");
        discounts.add("Custom");

        DiscountAdapter adapter = new DiscountAdapter(discounts);
        recyclerView.setAdapter(adapter);


        binding.buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onCancelSelectDiscount();
            }
        });
    }

    private class DiscountAdapter extends RecyclerView.Adapter<DiscountAdapter.DiscountViewHolder> {
        private final ArrayList<String> discounts;

        public DiscountAdapter(ArrayList<String> discounts) {
            this.discounts = discounts;
        }

        @NonNull
        @Override
        public DiscountViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(getActivity()).inflate(R.layout.row_item, parent, false);
            return new DiscountViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull DiscountAdapter.DiscountViewHolder holder, int position) {
            holder.textViewDiscount.setText(discounts.get(position));
        }

        @Override
        public int getItemCount() {
            return discounts.size();
        }

        public class DiscountViewHolder extends RecyclerView.ViewHolder {
            TextView textViewDiscount;
            public DiscountViewHolder(@NonNull View itemView) {
                super(itemView);
                textViewDiscount = itemView.findViewById(R.id.textViewRowItem);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION) {
                            String sDiscount = discounts.get(position);
                            double discount;
                            if(sDiscount.equals("Custom")) {
                                discount = (double) binding.seekBar.getProgress();
                            } else {
                                sDiscount = sDiscount.replace("%", "");
                                discount = Double.parseDouble(sDiscount);
                            }
                            mListener.onDiscountSelected(discount);
                        }
                    }
                });
            }
        }
    }

    SelectDiscountListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof SelectDiscountListener) {
            mListener = (SelectDiscountListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement SelectDiscountListener");
        }
    }

    interface SelectDiscountListener {
        void onDiscountSelected(double discount);
        void onCancelSelectDiscount();
    }
}