package edu.uncc.assignment12;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import edu.uncc.assignment12.databinding.BillRowItemsBinding;
import edu.uncc.assignment12.databinding.FragmentBillsBinding;

public class BillsFragment extends Fragment {
    public BillsFragment() {
        // Required empty public constructor
    }

    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    FragmentBillsBinding binding;
    private ArrayList<Bill> mBills = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentBillsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = binding.recyclerView;
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        BillAdapter adapter = new BillAdapter(mBills);
        recyclerView.setAdapter(adapter);


        mBills.clear();
        mBills.addAll(mListener.getAllBills());

        binding.buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBills.clear();
                mListener.clearAllBills();
                adapter.notifyDataSetChanged();
            }
        });

        binding.buttonNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoCreateBill();
            }
        });


    }

    private class BillAdapter extends RecyclerView.Adapter<BillAdapter.BillViewHolder> {
        private final ArrayList<Bill> bills;
        public BillAdapter(ArrayList<Bill> bills) { this.bills = bills;}


        @NonNull
        @Override
        public BillViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            BillRowItemsBinding binding = BillRowItemsBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new BillViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull BillAdapter.BillViewHolder holder, int position) {
            Bill bill = bills.get(position);
            holder.bind(bill, position);
        }

        @Override
        public int getItemCount() { return bills.size(); }

        public class BillViewHolder extends RecyclerView.ViewHolder {
            BillRowItemsBinding binding;
            public BillViewHolder(BillRowItemsBinding binding) {
                super(binding.getRoot());
                this.binding = binding;

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION) {
                            Bill bill = bills.get(position);
                            mListener.goToBillSummary(bill);
                        }
                    }
                });

            }
            public void bind(Bill bill, int position) {
                binding.textViewName.setText(bill.getName());
                binding.textViewAmount.setText(String.valueOf(bill.getAmount()));
                binding.textViewDiscount.setText(String.valueOf(bill.getDiscount()));

                Double finalBill = bill.getAmount() - (bill.getAmount() * (bill.getDiscount() / 100));
                binding.textViewTotal.setText(String.valueOf(finalBill));

                Date billDate = bill.getBillDate();
                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                String formattedDate = dateFormat.format(billDate);
                binding.textViewDate.setText(formattedDate);

                binding.textViewCategorys.setText(bill.getCategory());

                binding.editBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mListener.goToEditBill(bill);
                    }
                });
                binding.deleteBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mBills.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, mBills.size());
                    }
                });
            }
        }


    }

    BillsListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof BillsListener) {
            mListener = (BillsListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement BillsListener");
        }
    }

    interface BillsListener {
        void goToBillSummary(Bill bill);
        void goToEditBill(Bill bill);
        ArrayList<Bill> getAllBills();
        void gotoCreateBill();
        void clearAllBills();
    }
}