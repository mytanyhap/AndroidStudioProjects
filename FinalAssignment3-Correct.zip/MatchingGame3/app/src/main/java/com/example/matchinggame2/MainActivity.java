//Assignment #3
//FinalAssignment3-Correct
//Brianna Lewis, Trinity Wells,Tee Peoples

package com.example.matchinggame2;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView textViewPrompt;
    private int[] imageViewCardIds = {
            R.id.imageView1, R.id.imageView2, R.id.imageView3, R.id.imageView4, R.id.imageView5,
            R.id.imageView6, R.id.imageView7, R.id.imageView8, R.id.imageView9, R.id.imageView10,
            R.id.imageView11, R.id.imageView12, R.id.imageView13, R.id.imageView14, R.id.imageView15,
            R.id.imageView16, R.id.imageView17, R.id.imageView18, R.id.imageView19, R.id.imageView20,
            R.id.imageView21, R.id.imageView22, R.id.imageView23, R.id.imageView24, R.id.imageView25
    };

    private ImageView[] imageViews;

    private int focusImage;
    private int focusCount;
    private ArrayList<Integer> selectedFocusImages;
    private Map<Integer, String> drawableNamesMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        textViewPrompt = findViewById(R.id.textViewPrompt);

        imageViews = new ImageView[imageViewCardIds.length];
        for (int i = 0; i < imageViewCardIds.length; i++) {
            imageViews[i] = findViewById(imageViewCardIds[i]);
            imageViews[i].setOnClickListener(this); // Set click listener for each ImageView
        }

        findViewById(R.id.buttonReset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setUpNewGame();
            }
        });

        initializeDrawableNamesMap();
        selectedFocusImages = new ArrayList<>();
        setUpNewGame();
    }

    private void initializeDrawableNamesMap() {
        drawableNamesMap = new HashMap<>();
        drawableNamesMap.put(R.drawable.apple, "Apples");
        drawableNamesMap.put(R.drawable.lemon, "Lemons");
        drawableNamesMap.put(R.drawable.mango, "Mangos");
        drawableNamesMap.put(R.drawable.strawberry, "Strawberries");
        drawableNamesMap.put(R.drawable.tomato, "Tomatoes");
        drawableNamesMap.put(R.drawable.peach, "Peaches");
    }

    private String getDrawableName(int drawableId) {
        return drawableNamesMap.getOrDefault(drawableId, "Unknown");
    }

    private void setUpNewGame() {
        Random random = new Random();

        int[] drawableCardIds = {
                R.drawable.apple, R.drawable.lemon, R.drawable.mango,
                R.drawable.strawberry, R.drawable.tomato, R.drawable.peach
        };

        focusImage = drawableCardIds[random.nextInt(drawableCardIds.length)];
        focusCount = random.nextInt(8) + 1;

        String focusName = getDrawableName(focusImage);
        textViewPrompt.setText(String.format("Find All %s (%d)", focusName, focusCount));

        ArrayList<Integer> shuffledDrawableIds = new ArrayList<>();
        ArrayList<Integer> availableImages = new ArrayList<>();

        for (int drawableId : drawableCardIds) {
            if (drawableId != focusImage) {
                availableImages.add(drawableId);
            }
        }

        for (int i = 0; i < focusCount; i++) {
            shuffledDrawableIds.add(focusImage);
        }
        while (shuffledDrawableIds.size() < imageViewCardIds.length) {
            shuffledDrawableIds.add(availableImages.get(random.nextInt(availableImages.size())));
        }
        Collections.shuffle(shuffledDrawableIds);

        for (int i = 0; i < imageViews.length; i++) {
            imageViews[i].setImageResource(shuffledDrawableIds.get(i));
            imageViews[i].setTag(shuffledDrawableIds.get(i));
            imageViews[i].setAlpha(1.0f); // Reset alpha to fully opaque
            imageViews[i].setClickable(true);
        }
    }

    @Override
    public void onClick(View v) {
        ImageView clickedImageView = (ImageView) v;
        int clickedImageId = (Integer) clickedImageView.getTag();

        Log.d("demo", "Clicked Image ID: " + clickedImageId);

        if (clickedImageId != focusImage) {
            // Ignore clicks on non-focus images
            return;
        }

        if (selectedFocusImages.contains(clickedImageId)) {
            // Ignore clicks on already selected focus images

        }

        selectedFocusImages.add(clickedImageId);
        clickedImageView.setAlpha(0.3f); // Make the clicked image less sharp
        clickedImageView.setClickable(false); // Disable click on the selected image

        // Update focus count
        focusCount--;

        if (focusCount == 0) {
            // All focus images found
            textViewPrompt.setText(String.format("Found All %s", getDrawableName(focusImage)));
            showCompletionDialog();
        } else {
            // Update prompt text
            textViewPrompt.setText(String.format("Find All %s (%d)", getDrawableName(focusImage), focusCount));
            shuffleImages(); // Shuffle images after a click
        }
    }

    private void shuffleImages() {
        Random random = new Random();

        // Create a list to hold all drawable IDs and their states (alpha and clickability)
        ArrayList<ImageViewState> imageViewStates = new ArrayList<>();

        // Store the current state of all ImageViews
        for (ImageView imageView : imageViews) {
            imageViewStates.add(new ImageViewState(
                    (Integer) imageView.getTag(),
                    imageView.getAlpha(),
                    imageView.isClickable()
            ));
        }

        // Shuffle the drawable IDs
        Collections.shuffle(imageViewStates, random);

        // Reassign shuffled images and restore their states
        for (int i = 0; i < imageViews.length; i++) {
            ImageViewState state = imageViewStates.get(i);
            imageViews[i].setImageResource(state.drawableId);
            imageViews[i].setTag(state.drawableId);
            imageViews[i].setAlpha(state.alpha);
            imageViews[i].setClickable(state.clickable);
        }
    }

    // Helper class to store the state of an ImageView
    private static class ImageViewState {
        int drawableId;
        float alpha;
        boolean clickable;

        ImageViewState(int drawableId, float alpha, boolean clickable) {
            this.drawableId = drawableId;
            this.alpha = alpha;
            this.clickable = clickable;
        }
    }


    private void showCompletionDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Congratulations!")
                .setMessage(String.format("You have found all the %s", getDrawableName(focusImage)))
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        setUpNewGame(); // Reset the game when the user clicks "Ok"
                    }
                })
                .show();
    }
}
